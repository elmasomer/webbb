<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <title>Gönderilen Bilgiler</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<div class="container mt-5">
    <h1>Gönderdiğiniz Bilgiler</h1>
    <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
        <p><strong>Ad Soyad:</strong> <?php echo htmlspecialchars($_POST["name"]); ?></p>
        <p><strong>E-posta:</strong> <?php echo htmlspecialchars($_POST["email"]); ?></p>
        <p><strong>Mesaj:</strong> <?php echo nl2br(htmlspecialchars($_POST["message"])); ?></p>
    <?php else: ?>
        <div class="alert alert-warning">Bu sayfaya doğrudan erişim sağlandı. Lütfen formu doldurun.</div>
    <?php endif; ?>
</div>
</body>
</html>
